package es.florida_Acceso_a_datos_Antonio.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
