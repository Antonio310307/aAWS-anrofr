package es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion;

public class DatosInvalidosException extends RuntimeException {
    public DatosInvalidosException(String message) {
        super(message);
    }
}