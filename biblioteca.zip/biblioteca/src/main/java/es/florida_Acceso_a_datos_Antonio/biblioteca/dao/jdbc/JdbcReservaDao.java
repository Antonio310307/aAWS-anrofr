package es.florida_Acceso_a_datos_Antonio.biblioteca.dao.jdbc;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.ReservaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Reserva;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.ReservaPeticion;

@Repository
public class JdbcReservaDao implements ReservaDao {

    private static final String SELECT_BASE = "SELECT id, pista_id, socio_id, fecha_reserva FROM reserva";

    private static final RowMapper<Reserva> MAPEADOR = (rs, numFila) -> new Reserva(
        rs.getInt("id"),
        rs.getInt("pista_id"),
        rs.getInt("socio_id"),
        rs.getDate("fecha_reserva") != null ? rs.getDate("fecha_reserva").toLocalDate() : null
    );

    private final JdbcClient jdbc;

    public JdbcReservaDao(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public List<Reserva> buscarTodos() {
        return jdbc.sql(SELECT_BASE).query(MAPEADOR).list();
    }

    @Override
    public Optional<Reserva> buscarPorId(int id) {
        return jdbc.sql(SELECT_BASE + " WHERE id = :id")
                   .param("id", id)
                   .query(MAPEADOR)
                   .optional();
    }

    @Override
    public int insertar(ReservaPeticion datos) {
        KeyHolder clave = new GeneratedKeyHolder();
        jdbc.sql("INSERT INTO reserva (socio_id, pista_id, fecha_reserva) VALUES (:idSocio, :idPista, :fechaReserva)")
            .param("idSocio", datos.idSocio())
            .param("idPista", datos.idPista())
            .param("fechaReserva", datos.fechaReserva())
            .update(clave, "id");
        Number key = clave.getKey();
        return key != null ? key.intValue() : 0;
    }

    @Override
    public boolean actualizar(int id, ReservaPeticion datos) {
        int filasAfectadas = jdbc.sql("UPDATE reserva SET socio_id = :idSocio, pista_id = :idPista, fecha_reserva = :fechaReserva WHERE id = :id")
            .param("idSocio", datos.idSocio())
            .param("idPista", datos.idPista())
            .param("fechaReserva", datos.fechaReserva())
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }

    @Override
    public boolean eliminar(int id) {
        int filasAfectadas = jdbc.sql("DELETE FROM reserva WHERE id = :id")
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }

    @Override
    public int contarDesdeFechaDeSocio(int socioId, LocalDate desde) {
        return jdbc.sql("SELECT COUNT(*) FROM reserva WHERE socio_id = :socioId AND fecha_reserva >= :desde")
                   .param("socioId", socioId)
                   .param("desde", desde)
                   .query(Integer.class)
                   .single();
    }

    @Override
    public boolean existeDeSocioEnFecha(int socioId, LocalDate fecha) {
        return jdbc.sql("SELECT COUNT(*) FROM reserva WHERE socio_id = :socioId AND fecha_reserva = :fecha")
                   .param("socioId", socioId)
                   .param("fecha", fecha)
                   .query(Integer.class)
                   .single() > 0;
    }

    @Override
    public boolean existeDePistaEnFecha(int pistaId, LocalDate fecha) {
        return jdbc.sql("SELECT COUNT(*) FROM reserva WHERE pista_id = :pistaId AND fecha_reserva = :fecha")
                   .param("pistaId", pistaId)
                   .param("fecha", fecha)
                   .query(Integer.class)
                   .single() > 0;
    }

        @Override
    public boolean existeDeSocio(int socioId) {
        return jdbc.sql("SELECT COUNT(*) FROM reserva WHERE socio_id = :socioId")
                   .param("socioId", socioId)
                   .query(Integer.class)
                   .single() > 0;
    }

}