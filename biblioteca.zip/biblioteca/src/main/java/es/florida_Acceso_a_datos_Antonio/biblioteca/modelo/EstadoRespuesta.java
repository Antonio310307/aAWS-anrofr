package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

public record EstadoRespuesta(
    String alumno,
    int reservaMaximo,
    int reservaDias,
    String versionMysql,
    long memoriaUsadaMiB,
    long memoriaTotalMiB,
    long memoriaMaximaMiB
) {}
