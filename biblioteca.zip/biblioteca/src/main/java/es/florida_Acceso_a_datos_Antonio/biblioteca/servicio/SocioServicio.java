package es.florida_Acceso_a_datos_Antonio.biblioteca.servicio;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.ReservaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.SocioDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion.ConflictoException;
import es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion.RecursoNoEncontradoException;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Socio;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.SocioPeticion;

@Service
public class SocioServicio {

    private final SocioDao socioDao;
    private final ReservaDao reservaDao;

    public SocioServicio(SocioDao socioDao, ReservaDao reservaDao) {
        this.socioDao = socioDao;
        this.reservaDao = reservaDao;
    }

    public List<Socio> obtenerTodos() {
        return socioDao.buscarTodos();
    }

    public Socio obtenerPorId(int id) {
        return socioDao.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe el socio " + id));
    }

    @Transactional
    public Socio crearSocio(SocioPeticion peticion) {
        int id = socioDao.insertar(peticion);
        return obtenerPorId(id);
    }

    @Transactional
    public Socio actualizar(int id, SocioPeticion peticion) {
        obtenerPorId(id);                       // 404 si no existe
        socioDao.actualizar(id, peticion);
        return obtenerPorId(id);
    }

    @Transactional
    public void borrar(int id) {
        obtenerPorId(id);                       // 404 si no existe
        if (reservaDao.existeDeSocio(id)) {
            throw new ConflictoException(
                    "El socio " + id + " tiene reservas registradas y no se puede borrar");
        }
        socioDao.borrar(id);
    }
}