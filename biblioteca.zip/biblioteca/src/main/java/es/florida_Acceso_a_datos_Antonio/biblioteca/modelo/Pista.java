package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

public record Pista(int id, String nombre, String tipo, boolean disponible) {}