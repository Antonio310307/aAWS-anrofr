package es.florida_Acceso_a_datos_Antonio.biblioteca.dao;

import java.util.List;
import java.util.Optional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Pista;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaMasReservadaDto;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaPeticion;

public interface PistaDao {
    List<Pista> buscarTodos();
    Optional<Pista> buscarPorId(int id);
    Optional<Pista> buscarPorIdBloqueando(int id);
    int insertar(PistaPeticion datos);
    boolean actualizar(int id, PistaPeticion datos);
    boolean borrar(int id);
    List<PistaMasReservadaDto> obtenerMasReservadas(int limite);
}