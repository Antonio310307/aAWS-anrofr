package es.florida_Acceso_a_datos_Antonio.biblioteca.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Reserva;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.ReservaPeticion;

public interface ReservaDao {
    List<Reserva> buscarTodos();
    Optional<Reserva> buscarPorId(int id);
    int insertar(ReservaPeticion datos);
    boolean actualizar(int id, ReservaPeticion datos);
    boolean eliminar(int id);
    int contarDesdeFechaDeSocio(int socioId, LocalDate desde);
    boolean existeDeSocioEnFecha(int socioId, LocalDate fecha);
    boolean existeDePistaEnFecha(int pistaId, LocalDate fecha);
    boolean existeDeSocio(int socioId);
}