package es.florida_Acceso_a_datos_Antonio.biblioteca.dao.jdbc;

import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.PistaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Pista;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaMasReservadaDto;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaPeticion;

@Repository
public class JdbcPistaDao implements PistaDao {

    private static final String SELECT_BASE = "SELECT id, nombre, tipo, disponible FROM pista";
    private static final RowMapper<Pista> MAPEADOR = (rs, numFila) -> new Pista(
        rs.getInt("id"),
        rs.getString("nombre"),
        rs.getString("tipo"),
        rs.getBoolean("disponible")
    );

    private final JdbcClient jdbc;

    public JdbcPistaDao(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public List<Pista> buscarTodos() {
        return jdbc.sql(SELECT_BASE).query(MAPEADOR).list();
    }

    @Override
    public Optional<Pista> buscarPorId(int id) {
        return jdbc.sql(SELECT_BASE + " WHERE id = :id")
                   .param("id", id)
                   .query(MAPEADOR)
                   .optional();
    }

    @Override
    public Optional<Pista> buscarPorIdBloqueando(int id) {
        return jdbc.sql(SELECT_BASE + " WHERE id = :id FOR UPDATE")
                   .param("id", id)
                   .query(MAPEADOR)
                   .optional();
    }

    @Override
    public int insertar(PistaPeticion datos) {
        KeyHolder clave = new GeneratedKeyHolder();
        jdbc.sql("INSERT INTO pista (nombre, tipo, disponible) VALUES (:nombre, :tipo, :disponible)")
            .param("nombre", datos.nombre())
            .param("tipo", datos.tipo())
            .param("disponible", datos.disponible())
            .update(clave, "id");
        Number key = clave.getKey();
        return key != null ? key.intValue() : 0;
    }

    @Override
    public boolean actualizar(int id, PistaPeticion datos) {
        int filasAfectadas = jdbc.sql("UPDATE pista SET nombre = :nombre, tipo = :tipo, disponible = :disponible WHERE id = :id")
            .param("nombre", datos.nombre())
            .param("tipo", datos.tipo())
            .param("disponible", datos.disponible())
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }

    @Override
    public boolean borrar(int id) {
        int filasAfectadas = jdbc.sql("DELETE FROM pista WHERE id = :id")
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }

    @Override
    public List<PistaMasReservadaDto> obtenerMasReservadas(int limite) {
        String sql = """
            SELECT p.id, p.nombre AS titulo, COUNT(r.id) AS total_reservas
            FROM pista p
            LEFT JOIN reserva r ON p.id = r.pista_id
            GROUP BY p.id, p.nombre
            ORDER BY total_reservas DESC, p.id ASC
            LIMIT :limite
        """;

        return jdbc.sql(sql)
                .param("limite", limite)
                .query((rs, numFila) -> new PistaMasReservadaDto(
                        rs.getInt("id"),
                        rs.getString("titulo"),
                        rs.getInt("total_reservas")
                ))
                .list();
    }
}