package es.florida_Acceso_a_datos_Antonio.biblioteca.dao.jdbc;

import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.SocioDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Socio;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.SocioPeticion;

@Repository
public class JdbcSocioDao implements SocioDao {

    private static final String SELECT_BASE = "SELECT id, nombre, email, fecha_alta FROM socio";
    private static final RowMapper<Socio> MAPEADOR = (rs, numFila) -> new Socio(
        rs.getInt("id"),
        rs.getString("nombre"),
        rs.getString("email"),
        rs.getDate("fecha_alta") != null ? rs.getDate("fecha_alta").toLocalDate() : null
    );

    private final JdbcClient jdbc;

    public JdbcSocioDao(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public List<Socio> buscarTodos() {
        return jdbc.sql(SELECT_BASE).query(MAPEADOR).list();
    }

    @Override
    public Optional<Socio> buscarPorId(int id) {
        return jdbc.sql(SELECT_BASE + " WHERE id = :id")
                   .param("id", id)
                   .query(MAPEADOR)
                   .optional();
    }

    @Override
    public Optional<Socio> buscarPorIdBloqueando(int id) {
        return jdbc.sql(SELECT_BASE + " WHERE id = :id FOR UPDATE")
                   .param("id", id)
                   .query(MAPEADOR)
                   .optional();
    }

    @Override
    public int insertar(SocioPeticion datos) {
        KeyHolder clave = new GeneratedKeyHolder();
        jdbc.sql("INSERT INTO socio (nombre, email, fecha_alta) VALUES (:nombre, :email, CURDATE())")
            .param("nombre", datos.nombre())
            .param("email", datos.email())
            .update(clave, "id");
        Number key = clave.getKey();
        return key != null ? key.intValue() : 0;
    }

    @Override
    public boolean actualizar(int id, SocioPeticion datos) {
        int filasAfectadas = jdbc.sql("UPDATE socio SET nombre = :nombre, email = :email WHERE id = :id")
            .param("nombre", datos.nombre())
            .param("email", datos.email())
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }

    @Override
    public boolean borrar(int id) {
        int filasAfectadas = jdbc.sql("DELETE FROM socio WHERE id = :id")
            .param("id", id)
            .update();
        return filasAfectadas > 0;
    }
}