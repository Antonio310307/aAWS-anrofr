package es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion;

public class ConflictoException extends RuntimeException {
    public ConflictoException(String message){
        super(message);
    }
}
