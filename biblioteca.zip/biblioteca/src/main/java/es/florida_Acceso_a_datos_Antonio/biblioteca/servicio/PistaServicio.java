package es.florida_Acceso_a_datos_Antonio.biblioteca.servicio;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.PistaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Pista;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaMasReservadaDto;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaPeticion;

@Service
public class PistaServicio {

    private final PistaDao pistaDao;

    public PistaServicio(PistaDao pistaDao) {
        this.pistaDao = pistaDao;
    }

    public List<Pista> obtenerTodas() {
        return pistaDao.buscarTodos();
    }

    public Optional<Pista> obtenerPorId(int id) {
        return pistaDao.buscarPorId(id);
    }

    @Transactional
    public int crear(PistaPeticion peticion) {
        return pistaDao.insertar(peticion);
    }

    public List<PistaMasReservadaDto> obtenerMasReservadas(Integer limite) {
        int lim = (limite == null) ? 5 : limite;

        if (lim < 1 || lim > 20) {
            throw new IllegalArgumentException("El límite del informe debe estar entre 1 y 20");
        }

        return pistaDao.obtenerMasReservadas(lim);
    }
}