package es.florida_Acceso_a_datos_Antonio.biblioteca.web;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.EstadoRespuesta;
import es.florida_Acceso_a_datos_Antonio.biblioteca.servicio.EstadoServicio;

@RestController
@RequestMapping("/api/estado")
public class EstadoControler {

    private final EstadoServicio estadoServicio;

    public EstadoControler(EstadoServicio estadoServicio) {
        this.estadoServicio = estadoServicio;
    }

    @GetMapping
    public ResponseEntity<EstadoRespuesta> obtenerEstado() {
        EstadoRespuesta respuesta = estadoServicio.obtenerEstado();
        return ResponseEntity.ok(respuesta);
    }
}