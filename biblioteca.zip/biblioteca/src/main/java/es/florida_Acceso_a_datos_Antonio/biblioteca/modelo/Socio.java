package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

import java.time.LocalDate;

public record Socio(int id, String nombre, String email, LocalDate fechaAlta) {}