package es.florida_Acceso_a_datos_Antonio.biblioteca.dao.jdbc;

import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Repository;

import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.EstadoDao;

@Repository
public class JdbcEstadoDao implements EstadoDao {

    private final JdbcClient jdbc;

    public JdbcEstadoDao(JdbcClient jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public String obtenerVersion() {
        return jdbc.sql("SELECT VERSION()").query(String.class).single();
    }
}