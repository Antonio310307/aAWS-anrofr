package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

import java.time.LocalDate;

public record Reserva(int id, int pistaId, int socioId, LocalDate fechaReserva) {}