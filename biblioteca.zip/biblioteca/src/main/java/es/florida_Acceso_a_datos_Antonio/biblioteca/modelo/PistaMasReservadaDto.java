package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

public record PistaMasReservadaDto(
    int id,
    String titulo,
    int totalReservas
) {}