package es.florida_Acceso_a_datos_Antonio.biblioteca.dao;

import java.util.List;
import java.util.Optional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Socio;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.SocioPeticion;

public interface SocioDao {
    List<Socio> buscarTodos();
    Optional<Socio> buscarPorId(int id);
    Optional<Socio> buscarPorIdBloqueando(int id);
    int insertar(SocioPeticion datos);
    boolean actualizar(int id, SocioPeticion datos);
    boolean borrar(int id);
}