package es.florida_Acceso_a_datos_Antonio.biblioteca.config;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class FiltroAlumno extends OncePerRequestFilter {

    private final PolideportivoProperties propiedades;

    public FiltroAlumno(PolideportivoProperties propiedades) {
        this.propiedades = propiedades;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {
        response.setHeader("X-Alumno", propiedades.alumno());
        filterChain.doFilter(request, response);
    }
}