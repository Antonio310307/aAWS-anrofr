package es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion;

import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

@RestControllerAdvice
public class ManejadorErrores {

    @ExceptionHandler(RecursoNoEncontradoException.class)
    public ResponseEntity<Map<String, Object>> manejarNoEncontrado(
            RecursoNoEncontradoException ex, WebRequest request) {
        return construirRespuesta(HttpStatus.NOT_FOUND, ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(ConflictoException.class)
    public ResponseEntity<Map<String, Object>> manejarConflicto(
            ConflictoException ex, WebRequest request) {
        return construirRespuesta(HttpStatus.CONFLICT, ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(DuplicateKeyException.class)
    public ResponseEntity<Map<String, Object>> manejarClaveDuplicada(
            DuplicateKeyException ex, WebRequest request) {
        return construirRespuesta(HttpStatus.CONFLICT,
                "Ya existe un registro con ese valor (por ejemplo, un email repetido)", request, List.of());
    }

    @ExceptionHandler({DatosInvalidosException.class, IllegalArgumentException.class})
    public ResponseEntity<Map<String, Object>> manejarDatosInvalidos(
            RuntimeException ex, WebRequest request) {
        return construirRespuesta(HttpStatus.BAD_REQUEST, ex.getMessage(), request, List.of());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> manejarValidacion(
            MethodArgumentNotValidException ex, WebRequest request) {
        List<String> detalles = ex.getBindingResult().getFieldErrors().stream()
                .map(err -> err.getField() + ": " + err.getDefaultMessage())
                .collect(Collectors.toList());
        return construirRespuesta(HttpStatus.BAD_REQUEST,
                "Error de validación en los campos", request, detalles);
    }

    @ExceptionHandler({DataAccessResourceFailureException.class,
                       CannotCreateTransactionException.class})
    public ResponseEntity<Map<String, Object>> manejarBaseDatosNoDisponible(
            Exception ex, WebRequest request) {
        return construirRespuesta(HttpStatus.SERVICE_UNAVAILABLE,
                "La base de datos no está disponible en este momento", request, List.of());
    }

    private ResponseEntity<Map<String, Object>> construirRespuesta(
            HttpStatus estado, String mensaje, WebRequest request, List<String> detalles) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("marcaTemporal", OffsetDateTime.now().toString());
        cuerpo.put("estado", estado.value());
        cuerpo.put("error", estado.getReasonPhrase());
        cuerpo.put("mensaje", mensaje);
        cuerpo.put("ruta", request.getDescription(false).replace("uri=", ""));
        cuerpo.put("detalles", detalles);
        return ResponseEntity.status(estado).body(cuerpo);
    }

}