package es.florida_Acceso_a_datos_Antonio.biblioteca.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "biblioteca")
public record PolideportivoProperties(String alumno, Reserva reserva) {

    public record Reserva(int maximo, int dias) {}
}