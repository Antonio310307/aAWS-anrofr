package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;
import jakarta.validation.constraints.NotBlank;
public record PistaPeticion (
@NotBlank (message= "El nombre de la pista no puede estar vacío")
String nombre,

@NotBlank (message= "El tipo de pista no puede estar vacío")
String tipo, 

boolean disponible
) {}
