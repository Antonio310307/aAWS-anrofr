package es.florida_Acceso_a_datos_Antonio.biblioteca.servicio;

import org.springframework.stereotype.Service;

import es.florida_Acceso_a_datos_Antonio.biblioteca.config.PolideportivoProperties;
import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.EstadoDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.EstadoRespuesta;

@Service
public class EstadoServicio {

    private final EstadoDao estadoDao;
    private final PolideportivoProperties polideportivoProperties;

    public EstadoServicio(EstadoDao estadoDao, PolideportivoProperties polideportivoProperties) {
        this.estadoDao = estadoDao;
        this.polideportivoProperties = polideportivoProperties;
    }

    public EstadoRespuesta obtenerEstado() {
        String versionMysql = estadoDao.obtenerVersion();

        Runtime rt = Runtime.getRuntime();
        long memoriaUsadaMiB = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
        long memoriaTotalMiB = rt.totalMemory() / (1024 * 1024);
        long memoriaMaximaMiB = rt.maxMemory() / (1024 * 1024);

        String alumno = polideportivoProperties.alumno();
int reservaMaximo = polideportivoProperties.reserva().maximo();
int reservaDias = polideportivoProperties.reserva().dias();

        return new EstadoRespuesta(
            alumno,
            reservaMaximo,
            reservaDias,
            versionMysql,
            memoriaUsadaMiB,
            memoriaTotalMiB,
            memoriaMaximaMiB
        );
    }
}