package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
public record SocioPeticion (
    @NotBlank (message = "El nombre no puede estar vacío")
    String nombre,

    @NotBlank (message = "El email no puede estar vacío")
    @Email(message = "El formato del email no es válido")
    String email
){}
