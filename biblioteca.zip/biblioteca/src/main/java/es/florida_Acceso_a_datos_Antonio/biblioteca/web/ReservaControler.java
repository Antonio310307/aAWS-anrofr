package es.florida_Acceso_a_datos_Antonio.biblioteca.web;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Reserva;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.ReservaPeticion;
import es.florida_Acceso_a_datos_Antonio.biblioteca.servicio.ReservaServicio;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/reservas")
public class ReservaControler {

    private final ReservaServicio reservaServicio;

    public ReservaControler(ReservaServicio reservaServicio) {
        this.reservaServicio = reservaServicio;
    }

    @GetMapping
    public ResponseEntity<List<Reserva>> obtenerTodas() {
        return ResponseEntity.ok(reservaServicio.buscarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Reserva> obtenerPorId(@PathVariable int id) {
        return ResponseEntity.ok(reservaServicio.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<Reserva> crearReserva(@Valid @RequestBody ReservaPeticion peticion) {
        Reserva creada = reservaServicio.insertar(peticion);
        return ResponseEntity.created(URI.create("/api/reservas/" + creada.id())).body(creada);
    }
}