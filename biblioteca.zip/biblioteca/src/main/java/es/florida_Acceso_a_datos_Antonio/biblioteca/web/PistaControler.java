package es.florida_Acceso_a_datos_Antonio.biblioteca.web;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Pista;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaMasReservadaDto;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.PistaPeticion;
import es.florida_Acceso_a_datos_Antonio.biblioteca.servicio.PistaServicio;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class PistaControler {
    private final PistaServicio pistaServicio;

    public PistaControler(PistaServicio pistaServicio){
        this.pistaServicio = pistaServicio;
    }

    @GetMapping("/pistas") 
    public ResponseEntity<List<Pista>> obtenerTodas(){
        return ResponseEntity.ok(pistaServicio.obtenerTodas());
    }

    @GetMapping("/pistas/{id}")
    public ResponseEntity<Pista> obtenerPorId(@PathVariable int id){
        return pistaServicio.obtenerPorId(id).map(ResponseEntity::ok).orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @PostMapping("/pistas")
    public ResponseEntity<Integer> crearPista(@Valid @RequestBody PistaPeticion peticion){
        int idGenerado = pistaServicio.crear(peticion);
        return ResponseEntity.status(HttpStatus.CREATED).body(idGenerado);
    }

    @GetMapping("/informes/mas-prestados")
    public ResponseEntity<List<PistaMasReservadaDto>> obtenerMasPrestados(
            @RequestParam(required = false) Integer limite) {
        List<PistaMasReservadaDto> resultado = pistaServicio.obtenerMasReservadas(limite);
        return ResponseEntity.ok(resultado);
    }
}