package es.florida_Acceso_a_datos_Antonio.biblioteca.modelo;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public record ReservaPeticion (
     @NotNull(message = "El ID del socio no puede ser nulo")
    Integer idSocio,

    @NotNull (message = "El ID de la pista no puede ser nulo")
    Integer idPista,

    @NotNull (message = "La fecha de reserva no puede estar vacía")
    LocalDate fechaReserva

){}