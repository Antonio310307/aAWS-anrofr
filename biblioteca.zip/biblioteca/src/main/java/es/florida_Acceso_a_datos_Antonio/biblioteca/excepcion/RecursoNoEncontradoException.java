package es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion;

public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String message){
        super(message);
    }
}
