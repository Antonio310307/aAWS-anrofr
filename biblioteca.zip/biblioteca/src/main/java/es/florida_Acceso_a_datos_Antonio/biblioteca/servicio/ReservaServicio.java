package es.florida_Acceso_a_datos_Antonio.biblioteca.servicio;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import es.florida_Acceso_a_datos_Antonio.biblioteca.config.PolideportivoProperties;
import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.PistaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.ReservaDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.dao.SocioDao;
import es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion.ConflictoException;
import es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion.DatosInvalidosException;
import es.florida_Acceso_a_datos_Antonio.biblioteca.excepcion.RecursoNoEncontradoException;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Pista;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Reserva;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.ReservaPeticion;

@Service
public class ReservaServicio {

    private final ReservaDao reservaDao;
    private final PistaDao pistaDao;
    private final SocioDao socioDao;
    private final PolideportivoProperties propiedades;

    public ReservaServicio(ReservaDao reservaDao, PistaDao pistaDao, SocioDao socioDao,
                           PolideportivoProperties propiedades) {
        this.reservaDao = reservaDao;
        this.pistaDao = pistaDao;
        this.socioDao = socioDao;
        this.propiedades = propiedades;
    }

    public List<Reserva> buscarTodos() {
        return reservaDao.buscarTodos();
    }

    public Reserva obtenerPorId(int id) {
        return reservaDao.buscarPorId(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe la reserva " + id));
    }

    @Transactional
    public Reserva insertar(ReservaPeticion datos) {
        int pistaId = datos.idPista();
        int socioId = datos.idSocio();
        LocalDate fecha = datos.fechaReserva();
        LocalDate hoy = LocalDate.now();

        // Regla 1: existen (se bloquea SIEMPRE primero la pista y después el socio)
        Pista pista = pistaDao.buscarPorIdBloqueando(pistaId)
                .orElseThrow(() -> new DatosInvalidosException("No existe la pista " + pistaId));
        socioDao.buscarPorIdBloqueando(socioId)
                .orElseThrow(() -> new DatosInvalidosException("No existe el socio " + socioId));
        int dias = propiedades.reserva().dias();
        if (fecha.isBefore(hoy) || fecha.isAfter(hoy.plusDays(dias))) {
            throw new DatosInvalidosException(
                    "La fecha debe estar entre hoy y los próximos " + dias + " días");
        }

        if (!pista.disponible()) {
            throw new ConflictoException("La pista " + pistaId + " no está disponible");
        }

        int maximo = propiedades.reserva().maximo();
        if (reservaDao.contarDesdeFechaDeSocio(socioId, hoy) >= maximo) {
            throw new ConflictoException("El socio " + socioId + " ya tiene el máximo de "
                    + maximo + " reservas");
        }

        if (reservaDao.existeDeSocioEnFecha(socioId, fecha)) {
            throw new ConflictoException("El socio " + socioId + " ya tiene una reserva el " + fecha);
        }

        if (reservaDao.existeDePistaEnFecha(pistaId, fecha)) {
            throw new ConflictoException("La pista " + pistaId + " ya está reservada el " + fecha);
        }

        int id = reservaDao.insertar(datos);
        return obtenerPorId(id);
    }
}