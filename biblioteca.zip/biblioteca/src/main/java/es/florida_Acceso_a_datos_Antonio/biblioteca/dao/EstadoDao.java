package es.florida_Acceso_a_datos_Antonio.biblioteca.dao;

public interface EstadoDao {
    String obtenerVersion();
}
