package es.florida_Acceso_a_datos_Antonio.biblioteca.web;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.Socio;
import es.florida_Acceso_a_datos_Antonio.biblioteca.modelo.SocioPeticion;
import es.florida_Acceso_a_datos_Antonio.biblioteca.servicio.SocioServicio;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/socios")
public class SocioControler {

    private final SocioServicio socioServicio;

    public SocioControler(SocioServicio socioServicio) {
        this.socioServicio = socioServicio;
    }

    @GetMapping
    public ResponseEntity<List<Socio>> obtenerTodos() {
        return ResponseEntity.ok(socioServicio.obtenerTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Socio> obtenerPorId(@PathVariable int id) {
        return ResponseEntity.ok(socioServicio.obtenerPorId(id));
    }

    @PostMapping
    public ResponseEntity<Socio> crearSocio(@Valid @RequestBody SocioPeticion peticion) {
        Socio creado = socioServicio.crearSocio(peticion);
        return ResponseEntity.created(URI.create("/api/socios/" + creado.id())).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Socio> actualizar(@PathVariable int id,
                                            @Valid @RequestBody SocioPeticion peticion) {
        return ResponseEntity.ok(socioServicio.actualizar(id, peticion));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable int id) {
        socioServicio.borrar(id);
        return ResponseEntity.noContent().build();
    }
}