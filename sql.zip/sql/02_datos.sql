USE biblioteca;

-- 1. Eliminar tablas si estas existen
DROP TABLE IF EXISTS reserva;
DROP TABLE IF EXISTS socio;
DROP TABLE IF EXISTS pista;

-- 2. Crear las tablas
CREATE TABLE pista (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    tipo VARCHAR(50),
    disponible BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE socio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    email VARCHAR(160) UNIQUE NOT NULL,
    fecha_alta DATE NOT NULL
);

CREATE TABLE reserva (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pista_id INT NOT NULL,
    socio_id INT NOT NULL,
    fecha_reserva DATE NOT NULL,
    FOREIGN KEY (pista_id) REFERENCES pista(id),
    FOREIGN KEY (socio_id) REFERENCES socio(id)
);

-- INSERCCIÓN DE DATOS
INSERT INTO pista (id, nombre, tipo, disponible) VALUES 
(1, 'Pista de Tenis 1', 'Exterior', 1),
(2, 'Pista de Tenis 2', 'Exterior', 1),
(3, 'Pista de Tenis Cubierta', 'Interior', 1),
(4, 'Pista de Pádel 1', 'Exterior', 1),
(5, 'Pista de Pádel 2', 'Exterior', 1),
(6, 'Pista de Pádel Cubierta 1', 'Interior', 1),
(7, 'Pista de Pádel Cubierta 2', 'Interior', 1),
(8, 'Campo de Fútbol 7', 'Césped Artificial', 1),
(9, 'Campo de Fútbol 11', 'Césped Natural', 1),
(10, 'Pabellón Polideportivo (Baloncesto/Fútbol Sala)', 'Parquet Interior', 1),
(11, 'Piscina Olímpica (Calle 1)', 'Agua Cubierta', 1),
(12, 'Piscina Olímpica (Calle 2)', 'Agua Cubierta', 1);

INSERT INTO socio (id, nombre, email, fecha_alta) VALUES 
(1, 'Antoni Pérez', 'antoni@florida.es', '2026-09-01'),
(2, 'Maria Garcia', 'maria@florida.es', '2026-09-15'),
(3, 'Joan Martinez', 'j.martinez@gmail.com', '2026-01-10'),
(4, 'Laura Sanchis', 'laura.sanchis@outlook.com', '2026-01-15'),
(5, 'Carlos Gomez', 'cgomez@yahoo.es', '2026-02-01'),
(6, 'Ana Beltran', 'anabeltran@gmail.com', '2026-02-14'),
(7, 'Vicent Ferrer', 'vferrer@florida.es', '2026-03-05'),
(8, 'Elena Navarro', 'elena.nav@hotmail.com', '2026-03-20'),
(9, 'Marc Soler', 'msoler@gmail.com', '2026-04-02'),
(10, 'Sofi Vidal', 'svidal@florida.es', '2026-04-12'),
(11, 'David Pastor', 'dpastor@gmail.com', '2026-05-01'),
(12, 'Carla Albiol', 'calbiol@outlook.es', '2026-05-18'),
(13, 'Pau Ribes', 'pau.ribes@gmail.com', '2026-06-02'),
(14, 'Marta Rubio', 'mrubio@florida.es', '2026-06-19'),
(15, 'Guillem Grau', 'ggrau@gmail.com', '2026-07-04'),
(16, 'Silvia Cervera', 'scervera@hotmail.com', '2026-07-22'),
(17, 'Jaume Roig', 'jroig@florida.es', '2026-08-01'),
(18, 'Patricia Sales', 'psales@gmail.com', '2026-08-11'),
(19, 'Albert Pons', 'apons@yahoo.es', '2026-08-29'),
(20, 'Nerea Ortiz', 'nortiz@gmail.com', '2026-09-03'),
(21, 'Ramon Mas', 'rmas@florida.es', '2026-09-10'),
(22, 'Irene Bosch', 'ibosch@gmail.com', '2026-09-18'),
(23, 'Sergio Moya', 'smoya@hotmail.com', '2026-09-25'),
(24, 'Cristina Gil', 'cgil@gmail.com', '2026-10-01'),
(25, 'Jordi Serra', 'jserra@florida.es', '2026-10-08'),
(26, 'Alba Calvo', 'acalvo@gmail.com', '2026-10-15'),
(27, 'Xavier Torres', 'xtorres@outlook.com', '2026-10-22'),
(28, 'Clara Cano', 'ccano@florida.es', '2026-10-28'),
(29, 'Hector Soriano', 'hsoriano@gmail.com', '2026-11-01'),
(30, 'Marina Sanz', 'msanz@gmail.com', '2026-11-03'),
(31, 'Antonio Roca', 'antoniet07@gmail.com', '2026-09-15');


INSERT INTO reserva (pista_id, socio_id, fecha_reserva) VALUES 
(1, 1, '2026-11-05'),
(2, 2, '2026-11-06'),
(6, 3, '2026-11-06'),
(8, 4, '2026-11-07'),
(10, 5, '2026-11-07'),
(4, 6, '2026-11-08'),
(1, 7, '2026-11-08'),
(3, 8, '2026-11-09'),
(5, 9, '2026-11-09'),
(7, 10, '2026-11-10'),
(9, 11, '2026-11-10'),
(11, 12, '2026-11-11'),
(12, 13, '2026-11-11'),
(2, 14, '2026-11-12'),
(6, 15, '2026-11-12'),
(8, 16, '2026-11-13'),
(10, 17, '2026-11-13'),
(1, 18, '2026-11-14'),
(4, 19, '2026-11-14'),
(5, 20, '2026-11-15'),
(7, 21, '2026-11-15'),
(3, 22, '2026-11-16'),
(9, 23, '2026-11-16'),
(11, 24, '2026-11-17'),
(12, 25, '2026-11-17'),
(6, 26, '2026-11-18'),
(8, 27, '2026-11-18'),
(10, 28, '2026-11-19'),
(2, 29, '2026-11-19'),
(1, 30, '2026-11-20'),
(4, 1, '2026-11-20'),
(5, 2, '2026-11-21'),
(7, 3, '2026-11-21'),
(8, 5, '2026-11-22'),
(6, 7, '2026-11-22');